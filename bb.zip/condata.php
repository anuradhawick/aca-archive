<?php
	$host = "mysql2.000webhost.com";
	$username = "a5474620_root";
	$password = "asdwas1234";
	$database = "a5474620_host";
?>